{
    "server algorithms": {
        "programName": "encodertsp.xv5T",
        "algs": [
        ],
    },
}
