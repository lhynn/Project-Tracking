/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-u17
 */

#ifndef encodertsp_config__
#define encodertsp_config__



#endif /* encodertsp_config__ */ 
