/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-u17
 */

#ifndef decode_config__
#define decode_config__



#endif /* decode_config__ */ 
