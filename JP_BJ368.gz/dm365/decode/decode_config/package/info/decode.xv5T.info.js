{
    "server algorithms": {
        "programName": "decode.xv5T",
        "algs": [
        ],
    },
}
