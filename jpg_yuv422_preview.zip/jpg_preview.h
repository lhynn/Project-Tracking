#ifndef __JPG_PREVIEW__
#define __JPG_PREVIEW__
#include <stdio.h>
#include <string.h>

#include <xdc/std.h>

#include <ti/sdo/ce/Engine.h>
#include <ti/sdo/ce/CERuntime.h>

#include <ti/sdo/dmai/Dmai.h>
#include <ti/sdo/dmai/Buffer.h>
#include <ti/sdo/dmai/ColorSpace.h>
#include <ti/sdo/dmai/ce/Idec1.h>
#include <ti/sdo/dmai/BufferGfx.h>
#include <xdc/std.h>
#include "../ctrl.h"

#include <ti/sdo/dmai/ColorSpace.h>

#define 		I_JPG_WID			736
#define 		I_JPG_HID			576

#define			Jpg_zoom_WID   		304//304
#define 		Jpg_zoom_HID   		224//240

/*视频解码处?�?�?�?�宏*/
#define 		i_OFFSETY				0				//解码?�Buffer?��?#define 		i_OFFSETX				24
#define 		i_OFFSETX                0

#define 		i_HEIGHT 				576		
#define 		i_LINELEN 				736

#define			i_AFTZOOMH				224//240
#define			i_AFTZOOMW				330//330
#define			i_DISZOOMW				308//308
#define 	 	CIRCULARADIUS			 44				

/*
* Using....
*   int main(){
*
*       JPG_DATA_FORMAT my_date;       //�����ȡ���ݵĸ�ʽ
*       JPG_Decode_Engine_Init();      //��ʼ��������
*
*       while(1){
*         JPG_Decode_File_Open("/JPG_00021.jpg");             //���ļ� && ����&&ת��
*         my_date = JPG_Get_Zoom_Decode_Date(Jpg_zoom_WID,Jpg_zoom_HID); //��ȡ���ź������
*            if (my_date == NULL) {
*                printf("Failed to JPG_Get_Zoom_Decode_Date\n");
*                return 0;
*             }    
*        JPG_Decode_File_Close();                      //�ر��ļ�
*     // After_Jpg_Date_To_Diplay(hDisBuf);            //��ʾ��ƵĻhDisBuf Display������
*        After_Zoom_To_Display_jpg(hDisBuf,my_date,30 ,14);        //�����ź��������ʾ
*     }
*     JPG_Decode_Engine_Destory();
*   }
*/



/*JPG_DATA_FORMAT:
 *			JPG缩放后?�?�� */
typedef  unsigned char * 	JPG_DATA_FORMAT;	


/*After_Jpg_Date_To_Diplay:
 *		Show JPG to Screen
 *		Parameters：
 *					[in] dis_Dstbuf				:Display Buffer
 *		Return values:
 *					Void
 */
void After_Jpg_Date_To_Diplay(Buffer_Handle hSrcBuf);

/*After_Zoom_To_Display_jpg:
 *		Show JPG to Screen after zoom 
 *		Parameters：
 *					[in] hSrcBuf				:Display Buffer
 *					[in] ZoomPtr				:need show date
 *					[in] offsetx				:relative screen level offset
 *					[in] offsety				:relative screen vertical offset
 *		Return values:
 *					Void
 */
Void After_Zoom_To_Display_jpg(Buffer_Handle hSrcBuf,JPG_DATA_FORMAT ZoomPtr,int offsetx,int offsety);



/*JPG_DATA_FORMAT:
 *		Init jpegdec Engine
 *		Parameters：
 *						Void
 *		Return values:
 *				-1 				:Faild
 *				 0				:Successful
 */
Int  JPG_Decode_Engine_Init	  			(Void);
/*JPG_Decode_Engine_Destory:
 *		free jpegdec Engine
 *		Parameters：
 *						Void
 *		Return values:
 *						Void
 */
Void JPG_Decode_Engine_Destory(Void);


/*JPG_Decode_File_Open:
 *		Open jpg file and decode
 *		Parameters：
 *				[in] filepath			:Need decode JPG file path
 *		Return values:
 *				-1 						:Faild
 *				 0						:Successful
 */
Int  JPG_Decode_File_Open (unsigned char * filepath);
/*JPG_Decode_File_Close:
 *		close jpg file 
 *		Parameters：
 *						Void
 *		Return values:
 *						Void
 */
Void JPG_Decode_File_Close(Void);


/*JPG_Get_Zoom_Decode_Date:
 *		Get zoom date 
 *		Parameters：
 *					[in] DstWidth			:Need yuv420sp date width after Zoom
 *					[in] DstHeight			:Need yuv420sp date height after Zoom
 *		Return values:
 *					JPG_DATA_FORMAT			:Get yuv420sp date pointer.
 *					NULL					:Get date error.
 */
JPG_DATA_FORMAT  JPG_Get_Zoom_Decode_Date(Int DstWidth,Int DstHeight);
/*JPG_Destory_Zoom_Decode_Date:
 *		Free zoom date 
 *		Parameters：
 *					[in] Data				:Need freed date 
 *		Return values:
 *					Void
 */
Void JPG_Destory_Zoom_Decode_Date(JPG_DATA_FORMAT Data);


#endif

