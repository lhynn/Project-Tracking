#include "icommon.h"

#define printf(...) (((int (*)(const char *,...))0xc3e0ccfc)(__VA_ARGS__))

int main(int argc,char **argv){

	printf("hello world~\n");

	return 0;
}

